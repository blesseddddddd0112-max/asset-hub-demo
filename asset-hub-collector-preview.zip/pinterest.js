(() => {
  if(!globalThis.HubCollectorPolicy?.isPage(location.href))return;
  const pinterestSite=['www.pinterest.com','pinterest.com'].includes(location.hostname);
  document.dispatchEvent(new Event('hub-collector-dispose'));
  document.querySelectorAll('[data-hub-collector]').forEach(n=>n.remove());
  const runtimeListeners=[];
  const onMessage=fn=>{runtimeListeners.push(fn);chrome.runtime.onMessage.addListener(fn);};
  document.addEventListener('hub-collector-dispose',()=>{for(const fn of runtimeListeners){try{chrome.runtime.onMessage.removeListener(fn);}catch{}}},{once:true});
  function pinterestCandidate(image) {
    const cardNode = image instanceof Element ? image.closest('[data-test-id="pin"], [data-test-id="pin-closeup-image"], [data-test-id="visual-content-container"], a[href*="/pin/"]') : null;
    const video = image instanceof HTMLVideoElement ? image : cardNode?.querySelector('video');
    if (video) {
      const src = video.currentSrc || video.src || video.querySelector('source')?.src;
      const href = video.closest('a[href*="/pin/"]')?.href || cardNode?.querySelector('a[href*="/pin/"]')?.href || (/^\/pin\/\d+/.test(location.pathname) ? location.href : '');
      try { const url = new URL(src); if (url.protocol !== 'https:' || !/(^|\.)pinimg\.com$/.test(url.hostname) || url.username || url.password || url.port || !/\/pin\/\d+\/?(?:[?#]|$)/.test(href) || cardNode?.querySelector('[aria-label*="Promoted"]')) return null; } catch { return null; }
      return { imageUrl: src, mediaType: 'video', previewUrl: video.poster || cardNode?.querySelector('img')?.src || '', pinUrl: href.split(/[?#]/)[0], title: video.getAttribute('aria-label') || cardNode?.querySelector('img')?.alt || 'Pinterest 视频' };
    }
    if (!(image instanceof HTMLImageElement) || image.closest('video') || image.width < 100 || image.height < 100) return null;
    const card = image.closest('[data-test-id="pin"], [data-test-id="pin-closeup-image"], [data-test-id="closeup-image"], [data-test-id="visual-content-container"]') || image.closest('a[href*="/pin/"]');
    if (!card || card.querySelector('video, [data-test-id*="video"], [aria-label*="Promoted"]') || /(?:^|\s)\d{1,2}:\d{2}(?:\s|$)/.test(card.innerText || '')) return null;
    const href = image.closest('a[href*="/pin/"]')?.href || card.querySelector('a[href*="/pin/"]')?.href || (/^\/pin\/\d+/.test(location.pathname) ? location.href : '');
    if (!href || !/\/pin\/\d+\/?(?:[?#]|$)/.test(href)) return null;
    const options = (image.srcset || '').split(',').map(s => s.trim().split(/\s+/)).filter(p => /^\d+(?:\.\d+)?[wx]$/.test(p[1] || '')).sort((a, b) => parseFloat(b[1]) - parseFloat(a[1]));
    const src = options[0]?.[0] || image.currentSrc || image.src;
    try { if (new URL(src).protocol !== 'https:' || !/(^|\.)pinimg\.com$/.test(new URL(src).hostname)) return null; } catch { return null; }
    const preview = image.currentSrc || image.src;
    const previewUrl = /^https:\/\/(?:[a-z0-9-]+\.)*pinimg\.com\//.test(preview) ? preview : src;
    return { imageUrl: src, previewUrl, pinUrl: href.split(/[?#]/)[0], title: image.alt || 'Pinterest 图片' };
  }
  function candidate(element){return pinterestSite?pinterestCandidate(element):globalThis.HubWebCollector.candidate(element);}
  function elements(){return pinterestSite?[...document.querySelectorAll('video, img')]:globalThis.HubWebCollector.elements();}
  function scan() { const found = new Map(); for (const image of elements()) { const item = candidate(image); if (item && !found.has(item.key||item.pinUrl)) found.set(item.key||item.pinUrl, item); } return [...found.values()]; }
  onMessage((message, _, respond) => {
    if (message.type === 'collectorPing') respond({ready:true,role:'pinterest',scriptVersion:chrome.runtime.getManifest().version});
    if (message.type === 'scan') respond(scan());
    if (message.type === 'contextCandidate') respond([...document.querySelectorAll('video, img')].filter(img => [img.src, img.currentSrc].includes(message.src)).map(candidate).find(Boolean) || null);
  });
  const toolbar = globalThis.HubCollectorToolbar({ candidate, scan, elements });
  onMessage((message, _, respond) => {
    if(message.type === 'toggleToolbar') { toolbar.toggle(); respond(true); }
    if(message.type === 'showToolbar') { toolbar.show(); respond(true); }
  });
})();
