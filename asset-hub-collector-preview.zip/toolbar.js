// Per-image hover UI. All injected surfaces live in an isolated Shadow DOM.
globalThis.HubCollectorToolbar = function ({ candidate, scan, elements = () => [...document.querySelectorAll('video, img')] }) {
  const listeners = new AbortController();
  function listen(target,type,fn,options={}) { target.addEventListener(type,fn,{...(typeof options==='boolean'?{capture:options}:options),signal:listeners.signal}); }
  let activeReview=null;
  const host = document.createElement('div'); host.dataset.hubCollector = 'hover';
  host.style.cssText = 'position:fixed;inset:0;z-index:2147483647;pointer-events:none';
  const root = host.attachShadow({ mode: 'open' });
  const paths = { collect:'<path d="M12 3v12m-4-4 4 4 4-4M5 16v4h14v-4"/>',prompt:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z"/>',script:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',skill:'<path d="m12 3 9 9-9 9-9-9Z"/>',batch:'<rect x="7" y="7" width="14" height="14" rx="2"/><path d="M17 3H5a2 2 0 0 0-2 2v12"/>',history:'<path d="M4 5v5h5M4 10a8 8 0 1 1 1 8M12 7v5l3 2"/>',check:'<path d="m5 12 4 4L19 6"/>' };
  const logo = '<span aria-hidden="true">＋</span>';
  const svg = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]}</svg>`;
  root.innerHTML = `<style>${globalThis.HubCollectorStyles}</style><button class="hover-button" aria-label="打开素材采集菜单" title="采集到 Hub" aria-haspopup="menu" aria-expanded="false" hidden>${logo}<span>保存到Asset Hub</span></button><div class="menu" role="menu" aria-label="素材采集" hidden></div><section class="popover" aria-label="采集操作面板" hidden></section><div class="launcher" aria-label="Asset Hub采集设置" hidden></div><div class="batch-overlays"></div><div class="batch-bar" role="toolbar" aria-label="批量选择操作" hidden></div><div class="notice" role="status" hidden></div>`;
  document.documentElement.append(host);
  const icon=root.querySelector('.hover-button'),menu=root.querySelector('.menu'),pane=root.querySelector('.popover'),launcher=root.querySelector('.launcher'),marks=root.querySelector('.batch-overlays'),bar=root.querySelector('.batch-bar'),noticeEl=root.querySelector('.notice');
  let marksSignature='', reviewFilter='全部';
  let enabled=true,active=null,hideTimer,noticeTimer,historySignature='',submitting=false,batchMode=false,page=location.href;
  const itemKey=item=>item.key||item.pinUrl;
  const entries=new Map(),selection=new Set(),observed=new Map(); let savedPins=new Set();
  async function request(payload){
    for(let attempt=0;attempt<4;attempt++){
      let r;try{r=await chrome.runtime.sendMessage(payload);}catch(e){
        if(/context invalidated|Extension context/i.test(e.message))throw new Error('插件已更新，正在自动重连，请稍候');
        if(attempt===3)throw new Error('插件连接中断，正在自动重连；请稍后重试');
        await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));continue;
      }
      if(!r?.ok)throw new Error(r?.error||'插件未响应，请稍后重试');return r.result;
    }
  }
  function el(tag,text,className){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(className)n.className=className;return n;}
  function button(text,fn,className){const b=el('button',text,className);b.onclick=fn;return b;}
  function notice(text){clearTimeout(noticeTimer);noticeEl.textContent=text;noticeEl.hidden=false;noticeTimer=setTimeout(()=>noticeEl.hidden=true,5000);}
  function hideHover(){clearTimeout(hideTimer);if(menu.hidden){icon.hidden=true;active=null;}}
  function closeMenu(){menu.hidden=true;icon.setAttribute('aria-expanded','false');}
  function place(node,rect){node.hidden=false;const w=node.offsetWidth,h=node.offsetHeight;let x=rect.right+8;if(x+w>innerWidth-12)x=rect.left-w-8;if(x<12)x=Math.max(12,Math.min(rect.right-w,innerWidth-w-12));let y=Math.max(12,Math.min(rect.top,innerHeight-h-12));node.style.left=`${x}px`;node.style.top=`${y}px`;}
  function locate(target,x,y){
    if(!(target instanceof Element))return null;
    const card=target.closest('[data-test-id="pin"], [data-test-id="pin-closeup-image"], picture, figure, article, a[href]');
    let image=target instanceof HTMLVideoElement||target instanceof HTMLImageElement?target:card?.querySelector('video,img');
    let item=candidate(image);
    if(!item){let node=target;for(let i=0;node&&i<4;i++,node=node.parentElement){item=candidate(node);if(item){image=node;node.dataset.collectorBackground='1';break;}}}
    if(!item||!image)return null;
    const rect=image.getBoundingClientRect();if(x!==undefined&&(x<rect.left||x>rect.right||y<rect.top||y>rect.bottom))return null;return {image,item};
  }
  function showHover(found){
    clearTimeout(hideTimer);active=found;
    const rect=found.image.getBoundingClientRect();
    const saved=savedPins.has(itemKey(found.item));
    icon.innerHTML=logo+`<span>${saved?'已保存到Asset Hub':'保存到Asset Hub'}</span>`;
    icon.classList.toggle('saved',saved);icon.title=saved?'已收集 · 更多操作':'采集到 Hub';icon.hidden=false;
    // Mirror the native bottom-right action's inset and bottom edge.
    const card=found.image.closest('[data-test-id="pin"], [data-test-id="pin-closeup-image"], [data-test-id="closeup-image"], [data-test-id="visual-content-container"]')||found.image.closest('a[href*="/pin/"]');
    const actions=[...(card?.querySelectorAll('button, [role="button"]')||[])]
      .map(node=>node.getBoundingClientRect())
      .filter(r=>r.width>0&&r.height>0&&r.width<=64&&r.height<=64&&r.left>=rect.left+rect.width/2&&r.right<=rect.right+1&&r.top>=rect.top+rect.height/2&&r.bottom<=rect.bottom+1)
      .sort((a,b)=>b.right-a.right||b.bottom-a.bottom);
    const action=actions[0];
    const inset=action?Math.max(0,rect.right-action.right):12;
    const bottom=action?action.bottom:rect.bottom-12;
    // Keep the capsule size consistent on feed cards and detail images.
    icon.style.height='';
    icon.style.left=`${Math.max(8,Math.min(rect.left+inset,innerWidth-icon.offsetWidth-8))}px`;
    icon.style.top=`${Math.max(8,Math.min(bottom-icon.offsetHeight,innerHeight-icon.offsetHeight-8))}px`;
  }
  function openPane(title,rect){closeMenu();launcher.hidden=true;pane.dataset.view=title;delete pane.dataset.state;const row=el('div',undefined,'row');row.append(el('h2',title),button('×',()=>{pane.hidden=true;hideHover();},'close'));row.lastChild.setAttribute('aria-label','关闭操作面板');pane.replaceChildren(row);place(pane,rect||{left:innerWidth/2-150,right:innerWidth/2+150,top:70});}
  async function submit(item){const job=await request({type:'enqueue',item});observed.set(job.id,itemKey(item));if(['saved','existing'].includes(job.status)){savedPins.add(itemKey(item));notice('素材已在 灵感 / 灵感采集');}else notice('正在保存到 灵感 / 灵感采集…');return job;}
  const reverseTargets = [];
  function review(found,type='prompt',anchor=null,resume=null){
    const names={prompt:'提示词',script:'剧本',skill:'Skill'},name=names[type],rect=found.image?.getBoundingClientRect()||{left:innerWidth-360,right:innerWidth-16,top:56},item=found.item;
    openPane(`反解成${name}`,rect);const viewId=globalThis.HubCollectorPolicy.uuid();pane.dataset.reviewId=viewId;pane.dataset.state='idle';
    const alive=()=>host.isConnected&&!listeners.signal.aborted&&!pane.hidden&&pane.dataset.reviewId===viewId;
    const summary=el('div',undefined,'review-summary'),img=el(item.mediaType==='video'?'video':'img');img.src=item.mediaType==='video'?item.imageUrl:item.previewUrl||item.imageUrl;if(img instanceof HTMLVideoElement){img.controls=false;img.muted=true;img.preload='metadata';if(item.previewUrl)img.poster=item.previewUrl;}img.alt=item.title;summary.append(img);pane.append(summary);if(item.mediaType==='video')pane.append(el('p','视频按画面抽样理解，不包含音频与未采样镜头。','hint'));
    const heading=pane.querySelector('h2'),picker=el('div',undefined,'review-title-picker'),select=button(reverseTargets.find(target=>target.id===type).label,()=>{choices.hidden=!choices.hidden;select.setAttribute('aria-expanded',String(!choices.hidden));if(!choices.hidden)choices.querySelector('[aria-checked="true"]').focus();},'review-title-button'),choices=el('div',undefined,'review-title-menu');
    select.setAttribute('aria-label','切换反解类型');select.setAttribute('aria-haspopup','menu');select.setAttribute('aria-expanded','false');choices.setAttribute('role','menu');choices.setAttribute('aria-label','反解类型');choices.hidden=true;
    for(const target of reverseTargets){const option=button(target.label,()=>{const box=pane.getBoundingClientRect();review(found,target.id,{left:box.left,top:box.top});},'review-title-option');option.setAttribute('role','menuitemradio');option.setAttribute('aria-checked',String(target.id===type));choices.append(option);}
    picker.append(select,choices);heading.replaceChildren(picker);
    picker.addEventListener('focusout',event=>{if(!picker.contains(event.relatedTarget)){choices.hidden=true;select.setAttribute('aria-expanded','false');}});
    picker.addEventListener('keydown',event=>{if(event.key==='Escape'&&!choices.hidden){event.stopPropagation();choices.hidden=true;select.setAttribute('aria-expanded','false');select.focus();}if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();choices.hidden=false;select.setAttribute('aria-expanded','true');const options=[...choices.children],index=options.indexOf(root.activeElement);options[event.key==='Home'?0:event.key==='End'?options.length-1:(index+(event.key==='ArrowUp'?options.length-1:1))%options.length].focus();}});
    const purpose=el('textarea',undefined,'purpose-editor');purpose.setAttribute('aria-label',type==='skill'?'Skill 要完成的任务':'生成要求');purpose.placeholder=type==='skill'?'这个 Skill 以后要帮你完成什么？例如：参考图片生成产品广告分镜。':type==='script'?'可选：故事方向、时长、人物和用途':'可选：想复现整张图，还是只提取风格、构图？';purpose.value=resume?.instruction||'';if(type!=='prompt')pane.append(purpose);
    const generate=button(`生成${name}`,()=>void runGenerate(),'primary');pane.append(generate);
    const status=el('p','生成后可修改内容，确认后再保存。','hint');status.setAttribute('role','status');pane.append(status);
    const title=el('input',undefined,'artifact-title');title.setAttribute('aria-label','产物标题');title.placeholder='产物标题';if(type!=='prompt')pane.append(title);
    const editor=el('textarea',undefined,'prompt-editor');editor.setAttribute('aria-label','检查和编辑结果');editor.placeholder='';editor.disabled=true;
    const output=el('div',undefined,'generation-output'),loading=el('div',undefined,'generation-loading'),ring=el('div',undefined,'generation-ring'),percent=el('span','0%');loading.hidden=true;loading.setAttribute('role','progressbar');loading.setAttribute('aria-label',`${name}生成等待进度（估算）`);loading.setAttribute('aria-valuemin','0');loading.setAttribute('aria-valuemax','100');ring.append(percent);loading.append(ring);output.append(editor,loading);pane.append(output);
    function fitEditor(){editor.style.height='auto';const limit=Math.max(100,Math.min(360,innerHeight-230));editor.style.height=`${Math.min(limit,Math.max(100,editor.scrollHeight+2))}px`;editor.style.overflowY=editor.scrollHeight>limit?'auto':'hidden';requestAnimationFrame(()=>{if(alive()){const box=pane.getBoundingClientRect();pane.style.top=`${Math.max(12,Math.min(box.top,innerHeight-box.height-12))}px`;}});}
    const retry=button('',()=>void runGenerate(),'generation-retry');retry.hidden=true;retry.setAttribute('aria-label','重试生成');retry.title='重试生成';retry.innerHTML='<svg viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true"><path d="M19.5 9A8 8 0 1 0 20 14M19.5 4v5h-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';const failureLabel=el('span','生成失败','generation-failure-label');failureLabel.hidden=true;failureLabel.setAttribute('role','alert');loading.append(failureLabel);ring.append(retry);
    let progressTimer=null,progress=0,generating=false,failed=false,pendingId=resume?.pendingId||null;
    const clientRequestId=resume?.clientRequestId||globalThis.HubCollectorPolicy.uuid();
    activeReview=()=>alive()?({item,type,page:location.href,time:Date.now(),pendingId,clientRequestId,instruction:purpose.value,...(generatedId?{result:{title:title.value,text:editor.value}}:{})}):null;
    function showRetry(reason){pane.dataset.state='failed';output.setAttribute('aria-busy','false');failed=true;failureLabel.textContent=reason||'生成失败，请稍后重试';retry.title=failureLabel.textContent;output.classList.add('is-failed');failureLabel.hidden=false;loading.hidden=false;loading.classList.add('is-retry');loading.removeAttribute('role');loading.removeAttribute('aria-valuenow');loading.removeAttribute('aria-label');percent.hidden=true;retry.hidden=false;generate.hidden=true;}

    function setProgress(value){progress=value;percent.textContent=`${value}%`;loading.style.setProperty('--progress',`${value*3.6}deg`);loading.setAttribute('aria-valuenow',String(value));}
    function stopProgress(){clearInterval(progressTimer);progressTimer=null;loading.hidden=true;output.classList.remove('is-generating');}
    function startProgress(){pane.dataset.state='loading';output.setAttribute('aria-busy','true');output.classList.remove('is-failed');output.style.height=`${Math.max(180,output.getBoundingClientRect().height)}px`;failed=false;failureLabel.hidden=true;retry.hidden=true;percent.hidden=false;loading.classList.remove('is-retry');loading.setAttribute('role','progressbar');loading.setAttribute('aria-label','生成等待进度（估算）');setProgress(0);loading.hidden=false;output.classList.add('is-generating');generate.hidden=true;const started=Date.now();progressTimer=setInterval(()=>{if(!alive()){stopProgress();return;}setProgress(Math.min(95,Math.floor(95*(1-Math.exp(-(Date.now()-started)/26000)))));},300);}
    let generatedId=null,saving=false;
    const actions=el('div',undefined,'review-actions'),copy=button('复制',()=>{void navigator.clipboard.writeText(editor.value).then(()=>notice('已复制'),()=>notice('复制失败，请手动选择文本复制'));},'small'),save=button('保存至资产',()=>void saveResult(),'primary');copy.disabled=true;save.disabled=true;actions.append(copy,save);pane.append(actions);
    function loadGenerated(job){pane.dataset.state='ready';output.setAttribute('aria-busy','false');output.classList.remove('is-failed');output.style.height='';generatedId=job.id;title.value=job.result.title;editor.value=job.result.text;editor.disabled=false;fitEditor();copy.disabled=false;save.disabled=false;status.textContent=type==='skill'?'请检查输入、执行步骤、输出格式及工具依赖；保存为草稿，不会自动安装或运行。':type==='script'?'请检查分镜和时长；图片之外的故事内容属于创意扩写。':'请检查画面描述，修改后确认保存。';generate.hidden=true;}
    async function waitJob(id,terminals){
      while(alive()){
        const result=await request({type:'list'}),job=result.jobs.find(j=>j.id===id);
        if(!job)throw new Error('生成任务不存在');
        if(job.status==='failed')throw new Error(job.error||'处理失败');
        if(terminals.includes(job.status))return job;
        status.textContent=!result.connected?'资产库连接中断，正在自动重连，任务已保留…':job.status==='fetching'?'正在读取参考素材…':result.processingJobId===id?'正在处理当前素材，请稍候…':'任务已保留，正在排队等待处理…';
        await new Promise(resolve=>setTimeout(resolve,1200));
      }
      return null;
    }
    async function runGenerate(){if(saving||generating)return;if(type==='skill'&&!purpose.value.trim()){status.textContent='请先填写这个 Skill 要完成的任务。';purpose.focus();return;}generating=true;generate.disabled=true;save.disabled=true;copy.disabled=true;editor.disabled=true;purpose.disabled=true;title.disabled=true;status.textContent='正在建立生成任务…';startProgress();
      try{if(pendingId){await request({type:'retry',id:pendingId});}else{const job=await request({type:'generate',item,outputType:type,instruction:purpose.value,clientRequestId});pendingId=job.id;}const done=await waitJob(pendingId,['generated']);if(done&&alive()){setProgress(100);stopProgress();loadGenerated(done);}}
      catch(e){if(alive()){status.textContent='';stopProgress();showRetry(e.message);if(generatedId){editor.disabled=false;copy.disabled=false;save.disabled=false;}}}finally{generating=false;if(!failed)stopProgress();if(alive()){generate.hidden=true;generate.disabled=false;select.disabled=false;purpose.disabled=false;title.disabled=false;}}}
    async function saveResult(){if(!generatedId||saving)return;if(!editor.value.trim()){status.textContent='内容不能为空';return;}saving=true;pane.dataset.state='saving';save.textContent='正在保存…';save.disabled=true;generate.disabled=true;select.disabled=true;editor.disabled=true;purpose.disabled=true;title.disabled=true;status.textContent='正在保存…';try{const job=await request({type:'saveDocument',parentId:generatedId,text:editor.value,title:title.value});const done=await waitJob(job.id,['saved','existing']);if(done&&alive()){pane.dataset.state='saved';save.textContent='已保存';status.textContent=`${name}已保存到Asset Hub资产库`;notice(`${name}已保存到Asset Hub`);}}catch(e){if(alive()){pane.dataset.state='save-failed';status.textContent=e.message;save.textContent='重试保存';save.disabled=false;}}finally{saving=false;if(alive()){generate.disabled=false;select.disabled=false;editor.disabled=false;purpose.disabled=false;title.disabled=false;}}}
    editor.oninput=()=>{fitEditor();if(generatedId&&!saving){pane.dataset.state='ready';save.disabled=!editor.value.trim();save.textContent='保存至资产';}};
    if(resume?.result)loadGenerated({...resume,id:resume.pendingId});else fitEditor();place(pane,rect);
    if(anchor){pane.style.left=`${Math.max(12,Math.min(anchor.left,innerWidth-pane.offsetWidth-12))}px`;pane.style.top=`${Math.max(12,Math.min(anchor.top,innerHeight-pane.offsetHeight-12))}px`;}
    if((type==='prompt'||resume?.pendingId)&&!resume?.result)void runGenerate();
  }
  function openMenu(){if(!active)return;clearTimeout(hideTimer);const found=active;menu.replaceChildren();const add=(name,text,fn)=>{const b=button(text,fn);b.setAttribute('role','menuitem');menu.append(b);return b;};
    const collect=add('collect','采集素材',async()=>{closeMenu();icon.disabled=true;try{await submit(found.item);}catch(e){notice(e.message);}finally{icon.disabled=false;}});
    menu.append(el('div',undefined,'divider'));
    if(found.item.unsupported){collect.disabled=true;collect.title=found.item.unsupported;menu.append(el('p',found.item.unsupported,'hint'));}
    for(const target of (found.item.unsupported?[]:reverseTargets))add(target.id,target.label,()=>{const rect=menu.getBoundingClientRect();review(found,target.id,{left:rect.left,top:rect.top});},target.description);
    menu.append(el('div',undefined,'divider'));add('batch','批量采集',()=>void beginBatch().catch(e=>notice(e.message)));place(menu,icon.getBoundingClientRect());icon.setAttribute('aria-expanded','true');menu.querySelector('button')?.focus({preventScroll:true});}
  icon.onclick=()=>menu.hidden?openMenu():closeMenu();
  function updateBar(){const count=pane.querySelector('.review-count'),save=pane.querySelector('.review-save');if(count)count.textContent=`已选 ${selection.size} / ${entries.size}`;if(save){save.textContent=submitting?'正在保存…':`保存 ${selection.size} 项`;save.disabled=submitting||!selection.size;}}
  function refreshMarks(){if(!batchMode)return;if(page!==location.href){exitBatch();notice('页面已切换，已退出批量检查');return;}
    for(const image of elements()){const item=candidate(image);if(!item)continue;entries.set(itemKey(item),{image,item});}
    const signature=JSON.stringify([[...entries].map(([url,{item}])=>[url,item.imageUrl,selection.has(url),savedPins.has(url)]),submitting,reviewFilter]);
    if(signature===marksSignature){updateBar();return;}marksSignature=signature;
    const grid=pane.querySelector('.review-grid');if(!grid)return;grid.replaceChildren();const masonry=el('div',undefined,'review-masonry');grid.append(masonry);
    for(const [url,{item}]of entries){const kind=item.mediaType==='video'?'视频':'图片';if(reviewFilter!=='全部'&&reviewFilter!==kind)continue;const tile=el('label',undefined,`review-tile${selection.has(url)?' selected':''}`),img=el(item.mediaType==='video'&&!item.previewUrl?'video':'img'),input=el('input'),type=el('span',kind,'media-badge');img.src=item.previewUrl||item.imageUrl;if(img instanceof HTMLVideoElement){img.preload='metadata';img.muted=true;}img.alt='';img.loading='lazy';input.type='checkbox';input.checked=selection.has(url);input.disabled=submitting||savedPins.has(url)||Boolean(item.unsupported);input.setAttribute('aria-label',savedPins.has(url)?`已保存 ${item.title}`:`选择 ${item.title}`);tile.title=item.unsupported||item.title;input.onchange=()=>{input.checked?selection.add(url):selection.delete(url);tile.classList.toggle('selected',input.checked);updateBar();};tile.append(img,input,type);if(savedPins.has(url))tile.append(el('span','已保存','saved-label'));masonry.append(tile);}
    if(!masonry.children.length)masonry.append(el('p',entries.size?'当前筛选无素材':'未发现可采集素材，播放视频或滚动加载后重新扫描。','hint'));updateBar();}
  function exitBatch(){if(submitting)return;batchMode=false;marksSignature='';marks.replaceChildren();bar.hidden=true;pane.hidden=true;selection.clear();entries.clear();}
  async function beginBatch(){if(submitting)return;const result=await request({type:'list'});savedPins=new Set(result.jobs.filter(j=>['saved','existing'].includes(j.status)).map(j=>itemKey(j)));
    const rect=active?.image.getBoundingClientRect()||{left:innerWidth-370,right:innerWidth-16,top:60};openPane('批量采集',rect);icon.hidden=true;noticeEl.hidden=true;active=null;batchMode=true;page=location.href;entries.clear();selection.clear();marksSignature='';reviewFilter='全部';
    pane.querySelector('.close').onclick=exitBatch;
    const controls=el('div',undefined,'review-controls'),picker=el('div',undefined,'review-filter-picker'),choices=el('div',undefined,'review-title-menu review-filter-menu');
    const filter=button('全部',()=>{choices.hidden=!choices.hidden;filter.setAttribute('aria-expanded',String(!choices.hidden));if(!choices.hidden)choices.querySelector('[aria-checked="true"]').focus();},'review-title-button review-filter-button');
    filter.setAttribute('aria-label','素材类型');filter.setAttribute('aria-haspopup','menu');filter.setAttribute('aria-expanded','false');choices.setAttribute('role','menu');choices.setAttribute('aria-label','素材类型选项');choices.hidden=true;
    for(const value of ['全部','图片','视频']){const option=button(value,()=>{reviewFilter=value;filter.textContent=value;for(const child of choices.children)child.setAttribute('aria-checked',String(child===option));choices.hidden=true;filter.setAttribute('aria-expanded','false');filter.focus();refreshMarks();},'review-title-option');option.setAttribute('role','menuitemradio');option.setAttribute('aria-checked',String(value==='全部'));choices.append(option);}
    picker.append(filter,choices);picker.addEventListener('focusout',event=>{if(!picker.contains(event.relatedTarget)){choices.hidden=true;filter.setAttribute('aria-expanded','false');}});
    picker.addEventListener('keydown',event=>{if(event.key==='Escape'&&!choices.hidden){event.preventDefault();event.stopPropagation();choices.hidden=true;filter.setAttribute('aria-expanded','false');filter.focus();}if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();choices.hidden=false;filter.setAttribute('aria-expanded','true');const options=[...choices.children],index=options.indexOf(root.activeElement);options[event.key==='Home'?0:event.key==='End'?options.length-1:(index+(event.key==='ArrowUp'?options.length-1:1))%options.length].focus();}});
    controls.append(picker,button('扫描新增',()=>{refreshMarks();},'text-button'));pane.append(controls);
    const options=el('div',undefined,'row review-options');options.append(el('span','已选 0 / 0','review-count'),button('全选',()=>{for(const [url,{item}]of entries)if(!savedPins.has(url)&&!item.unsupported)selection.add(url);refreshMarks();},'text-button'),button('清空',()=>{selection.clear();refreshMarks();},'text-button'));pane.append(options,el('div',undefined,'review-grid'));
    const save=button('保存 0 项',async()=>{if(submitting||!selection.size)return;const items=[...selection].map(url=>entries.get(url)?.item).filter(Boolean);submitting=true;pane.querySelectorAll('button,select').forEach(b=>b.disabled=true);refreshMarks();let n=0;try{for(const item of items){await submit(item);selection.delete(itemKey(item));n++;}submitting=false;exitBatch();notice(`已提交 ${n} 项，正在保存到Asset Hub…`);}catch(e){submitting=false;pane.querySelectorAll('button,select').forEach(b=>b.disabled=false);refreshMarks();notice(`已提交 ${n} 项；${e.message}`);}},'primary review-save');pane.append(save);refreshMarks();place(pane,rect);
  }
  async function history(){if(submitting)return;if(batchMode)exitBatch();const result=await request({type:'list'});historySignature=JSON.stringify(result);openPane('采集任务',{left:innerWidth-330,right:innerWidth-20,top:54});pane.append(el('p',result.connected?'资产库已连接':'等待连接，打开资产库后继续保存','hint'));const labels={queued:'等待获取',fetching:'获取素材中',waiting:'等待资产库接收',saved:'已保存',existing:'已在资产库',failed:'处理失败',generated:'生成完成 · 待检查'};for(const job of result.jobs.sort((a,b)=>b.capturedAt.localeCompare(a.capturedAt)).slice(0,12)){const row=el('div',undefined,'job'),detail=el('div',undefined,'row');row.append(el('strong',job.title));detail.append(el('span',job.error||labels[job.status],job.status==='failed'?'error muted':['saved','existing'].includes(job.status)?'success muted':'muted'));if(job.status==='generated')detail.append(button('检查结果',()=>review({item:{title:job.title,imageUrl:job.imageUrl,pinUrl:job.pinUrl}},job.outputType,null,job),'small'));if(job.status==='failed')detail.append(button('重试',()=>request({type:'retry',id:job.id}).then(history).catch(e=>notice(e.message)),'small'));row.append(detail);pane.append(row);}if(!result.jobs.length)pane.append(el('p','还没有采集任务','hint'));pane.append(button('查看灵感 / 灵感采集 ↗',()=>request({type:'open'}).catch(e=>notice(e.message)),'footer'));}
  function showLauncher(){if(submitting){notice('正在提交所选素材，请稍候');return;}if(batchMode)exitBatch();closeMenu();pane.hidden=true;hideHover();launcher.replaceChildren(el('h2','Asset Hub'),el('p','保存到 灵感 / 灵感采集','hint'));launcher.append(button(enabled?'关闭悬浮采集':'开启悬浮采集',async()=>{enabled=!enabled;await chrome.storage.local.set({hoverEnabled:enabled});if(!enabled){hideHover();exitBatch();}showLauncher();}),button('批量采集',()=>beginBatch().catch(e=>notice(e.message))),button('采集任务',()=>history().catch(e=>notice(e.message))),button('查看资产库 ↗',()=>request({type:'open'}).catch(e=>notice(e.message))));launcher.hidden=false;}
  root.addEventListener('pointerover',()=>clearTimeout(hideTimer));
  listen(document,'pointerover',event=>{if(event.composedPath().includes(host))return;if(!enabled||batchMode||!menu.hidden||!pane.hidden)return;const found=locate(event.target,event.clientX,event.clientY);if(found)showHover(found);else{clearTimeout(hideTimer);hideTimer=setTimeout(hideHover,180);}});
  listen(document,'focusin',event=>{if(event.composedPath().includes(host)||!enabled||batchMode)return;const found=locate(event.target);if(found&&menu.hidden&&pane.hidden)showHover(found);});
  listen(document,'click',event=>{if(event.composedPath().includes(host))return;closeMenu();launcher.hidden=true;if(!batchMode)pane.hidden=true;},true);
  menu.addEventListener('keydown',event=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;event.preventDefault();const buttons=[...menu.querySelectorAll('button')],index=buttons.indexOf(root.activeElement);buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();});
  listen(document,'keydown',event=>{if(event.key==='Escape'){closeMenu();if(!submitting){pane.hidden=true;if(batchMode)exitBatch();}launcher.hidden=true;noticeEl.hidden=true;hideHover();}});
  let frame;function layout(event){if(event?.composedPath().includes(host))return;cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{if(batchMode)refreshMarks();else if(pane.hidden){closeMenu();hideHover();}});}listen(window,'scroll',layout,true);listen(window,'resize',layout);
  let mutationTimer;const observer=new MutationObserver(records=>{if(!batchMode||records.every(r=>host.contains(r.target)))return;clearTimeout(mutationTimer);mutationTimer=setTimeout(refreshMarks,150);});observer.observe(document.body,{childList:true,subtree:true});
  void chrome.storage.local.get('hoverEnabled').then(result=>{enabled=result.hoverEnabled!==false;});
  const interval=setInterval(async()=>{if(observed.size===0&&(pane.hidden||pane.dataset.view!=='采集任务'))return;try{const result=await request({type:'list'});if(!pane.hidden&&pane.dataset.view==='采集任务'&&JSON.stringify(result)!==historySignature)await history();for(const job of result.jobs)if(observed.has(job.id)&&['saved','existing','failed'].includes(job.status)){observed.delete(job.id);if(job.status==='failed')notice(job.error);else{savedPins.add(itemKey(job));if(active&&itemKey(active.item)===itemKey(job))showHover(active);notice('已保存到 灵感 / 灵感采集');}}}catch{}},2500);
  try{const pending=JSON.parse(sessionStorage.getItem('hub-collector:retry')||'null');sessionStorage.removeItem('hub-collector:retry');if(pending&&Date.now()-pending.time<300000&&pending.page===location.href&&pending.item?.pinUrl)requestAnimationFrame(()=>review({item:pending.item},pending.type,null,pending));}catch{}
  listen(document,'hub-collector-dispose',()=>{try{if(activeReview&&!pane.hidden)sessionStorage.setItem('hub-collector:retry',JSON.stringify(activeReview()));}catch{}listeners.abort();clearInterval(interval);clearTimeout(hideTimer);clearTimeout(noticeTimer);observer.disconnect();host.remove();},{once:true});
  return {toggle(){launcher.hidden?showLauncher():launcher.hidden=true;},show:showLauncher,destroy(){listeners.abort();clearInterval(interval);observer.disconnect();host.remove();}};
};
