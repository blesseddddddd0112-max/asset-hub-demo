const $ = id => document.getElementById(id);
let candidates = []; let known = new Set(); const selected = new Set(); let page = '';
const status = { queued: '等待获取素材', fetching: '正在获取素材', waiting: '等待资产库接收', saved: '已保存', existing: '已在资产库', failed: '采集失败' };
async function request(payload) { const r = await chrome.runtime.sendMessage(payload); if (!r.ok) throw new Error(r.error); return r.result; }
function hint(message) { $('hint').textContent = message; }
$('connect').onclick = $('view').onclick = () => request({ type: 'open' }).catch(e => hint(e.message));
function count() { $('count').textContent = `已选 ${selected.size} 张`; $('collect').disabled = !selected.size; }
function draw() {
  $('selection').hidden = !candidates.length; $('grid').replaceChildren();
  for (const item of candidates) {
    const label = document.createElement('label'); label.className = 'candidate';
    const input = document.createElement('input'); input.type = 'checkbox'; input.checked = selected.has(item.pinUrl); input.disabled = known.has(item.pinUrl); if (input.disabled) selected.delete(item.pinUrl); input.setAttribute('aria-label', `选择 ${item.title}`);
    input.onchange = () => { input.checked ? selected.add(item.pinUrl) : selected.delete(item.pinUrl); count(); };
    const image = document.createElement('img'); image.src = item.previewUrl || (item.mediaType === 'video' ? '' : item.imageUrl); image.alt = ''; image.loading = 'lazy';
    const title = document.createElement('span'); title.textContent = known.has(item.pinUrl) ? `已在资产库 · ${item.title}` : item.title;
    label.append(image, input, title); $('grid').append(label);
  } count();
}
$('scan').onclick = async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.id) throw new Error('请先打开 Pinterest 页面');
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'scan' },{frameId:0});
    if (page !== tab.url) { candidates = []; selected.clear(); page = tab.url; }
    const merged = new Map(candidates.map(i => [i.pinUrl, i])); result.forEach(i => merged.set(i.pinUrl, i)); candidates = [...merged.values()]; draw(); hint(`已发现 ${candidates.length} 项素材；滚动页面后可再次扫描。`);
  } catch { hint('请打开普通 HTTP / HTTPS 网页；浏览器内部页面不支持采集。'); }
};
$('all').onclick = () => { candidates.filter(i => !known.has(i.pinUrl)).forEach(i => selected.add(i.pinUrl)); draw(); };
$('none').onclick = () => { selected.clear(); draw(); };
$('collect').onclick = async () => {
  $('collect').disabled = true;
  try { let n = 0; for (const item of candidates.filter(i => selected.has(i.pinUrl))) { await request({ type: 'enqueue', item }); selected.delete(item.pinUrl); n++; } hint(`已提交 ${n} 项，保存结果请看下方任务。`); }
  catch (e) { hint(e.message); } finally { draw(); await refresh(); }
};
async function refresh() {
  try {
    const result = await request({ type: 'list' }); const nextKnown = new Set(result.jobs.filter(j => ['saved', 'existing'].includes(j.status)).map(j => j.pinUrl));
    if ([...nextKnown].sort().join('|') !== [...known].sort().join('|')) { known = nextKnown; draw(); }
    $('connection').textContent = result.connected ? '● 资产库已连接' : '○ 等待连接资产库';
    $('jobs').replaceChildren();
    if (!result.jobs.length) $('jobs').textContent = '还没有采集任务';
    for (const job of result.jobs.slice().sort((a,b)=>b.capturedAt.localeCompare(a.capturedAt))) {
      const row = document.createElement('div'); row.className = 'job'; const text = document.createElement('div'); const title = document.createElement('strong'); title.textContent = job.title;
      const detail = document.createElement('small'); detail.textContent = job.error || ({generated:'生成完成，待检查',processing:'正在处理'}[job.status] || status[job.status] || job.status); detail.className = job.status === 'failed' ? 'error' : ['saved', 'existing'].includes(job.status) ? 'success' : '';
      const metadata=document.createElement('small');metadata.textContent=`${job.kind==='transform'?'反解 '+job.outputType:job.kind==='document'?'保存产物':'采集素材'} · ${new Date(job.capturedAt).toLocaleString()} · ${job.provider||'网页素材'}`;text.append(title, detail,metadata); row.append(text);
      if (job.status === 'failed') { const retry = document.createElement('button'); retry.className = 'secondary'; retry.textContent = '重试'; retry.onclick = () => request({ type: 'retry', id: job.id }).then(refresh).catch(e => hint(e.message)); row.append(retry); }
      $('jobs').append(row);
    }
  } catch (e) { hint(e.message); }
}
void refresh(); setInterval(refresh, 2500);
