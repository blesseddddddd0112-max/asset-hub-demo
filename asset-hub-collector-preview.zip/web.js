(() => {
  const policy = globalThis.HubCollectorPolicy;
  function safe(value) { try { return policy.publicUrl(value); } catch { return ''; } }
  function source(element) {
    const linked=safe(element.closest('a[href]')?.href);
    return linked && new URL(linked).origin===location.origin && !/\.(?:jpe?g|png|gif|webp|avif|mp4|webm)(?:[?#]|$)/i.test(linked)?linked:safe(location.href);
  }
  function backgroundUrl(element) {
    const match = /^url\(["']?(.*?)["']?\)$/.exec(getComputedStyle(element).backgroundImage);
    return match ? safe(new URL(match[1], location.href).href) : '';
  }
  function candidate(element) {
    if (!(element instanceof Element) || element.closest('[data-hub-collector]')) return null;
    const rect = element.getBoundingClientRect();
    if (rect.width < 80 || rect.height < 80) return null;
    const video = element instanceof HTMLVideoElement;
    const image = element instanceof HTMLImageElement;
    if (image && element.closest('picture')?.querySelector('video')) return null;
    let url = '';
    if (video) url = [element.currentSrc,element.src,...[...element.querySelectorAll('source[src]')].map(n=>n.src),element.dataset.src].map(safe).find(Boolean)||'';
    else if (image) {
      const srcset = (element.srcset || '').split(',').map(s=>s.trim().split(/\s+/)).filter(p=>/^\d+(?:\.\d+)?[wx]$/.test(p[1]||'')).sort((a,b)=>parseFloat(b[1])-parseFloat(a[1]));
      url = [srcset[0]?.[0],element.currentSrc,element.src,element.dataset.src,element.dataset.original].filter(Boolean).map(value=>{try{return safe(new URL(value,location.href).href);}catch{return '';}}).find(Boolean)||'';
    } else url = backgroundUrl(element);
    const pinUrl = source(element);
    if (!pinUrl) return null;
    const unsupported = video && (!url || /\.(?:m3u8|mpd)(?:[?#]|$)/i.test(url)) ? '此视频尚未提供可下载文件地址，可能使用流式播放、登录保护或 DRM' : '';
    if (!url && !unsupported) return null;
    const mediaType = video ? 'video' : 'image';
    return { imageUrl:url, pinUrl, sourceUrl:pinUrl, provider:policy.provider(pinUrl), mediaType,
      previewUrl:video?safe(element.poster):safe(element.currentSrc||element.src)||url,
      title:element.getAttribute('alt')||element.getAttribute('aria-label')||element.getAttribute('title')||document.title||'网页素材',
      key:`${mediaType}:${url||pinUrl}`, unsupported };
  }
  function elements() {
    const media=[...document.querySelectorAll('img,video')];
    // CSS images are discovered on visible decorated elements, not on every DOM node.
    const decorated=[...document.querySelectorAll('[style*="background"], [data-collector-background]')];
    return [...media,...decorated];
  }
  globalThis.HubWebCollector = {candidate,elements,backgroundUrl};
})();
