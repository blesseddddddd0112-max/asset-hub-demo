import './media-policy.js';
export const APP = 'https://blesseddddddd0112-max.github.io/asset-hub-demo/';
export const MAX_BYTES = 20 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 100 * 1024 * 1024;
export const CHUNK = 256 * 1024;
export const mediaUrl = value => globalThis.HubCollectorPolicy.publicUrl(value);
export const sourceUrl = value => globalThis.HubCollectorPolicy.sourceUrl(value);
export const isCollectablePage = value => globalThis.HubCollectorPolicy.isPage(value);
export const sourceProvider = value => globalThis.HubCollectorPolicy.provider(value);
export function imageUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || !/(^|\.)pinimg\.com$/.test(url.hostname) || url.username || url.password || url.port) throw new Error('仅支持 Pinterest 图片地址');
  return url.href;
}
export function pinUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || !['www.pinterest.com', 'pinterest.com'].includes(url.hostname) || !/^\/pin\/\d+\/?$/.test(url.pathname)) throw new Error('无法识别 Pin 来源');
  return `https://www.pinterest.com${url.pathname.replace(/\/?$/, '/')}`;
}
export function isApp(value) {
  try { const u = new URL(value); return u.origin === 'https://blesseddddddd0112-max.github.io' && u.pathname.startsWith('/asset-hub-demo/'); } catch { return false; }
}
export function isPinterest(value) {
  try { const u = new URL(value); return u.protocol === 'https:' && ['www.pinterest.com', 'pinterest.com'].includes(u.hostname); } catch { return false; }
}
