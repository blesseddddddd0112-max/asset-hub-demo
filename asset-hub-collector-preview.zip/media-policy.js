// Shared by classic content scripts and the module service worker.
(() => {
  function publicUrl(value) {
    const url = new URL(value);
    const host = url.hostname.toLowerCase().replace(/\.$/, '');
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) throw new Error('仅支持 HTTP / HTTPS 网页素材地址');
    if (!host.includes('.') || /(?:^|\.)(?:localhost|local|internal|lan|home|test)$/.test(host) || host.includes(':')) throw new Error('暂不采集本机或内网地址');
    const ip = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(host);
    if (ip) {
      const [, a, b] = ip.map(Number);
      if (a===0 || a===10 || a===127 || a===169 && b===254 || a===172 && b>=16 && b<=31 || a===192 && b===168 || a===100 && b>=64 && b<=127 || a>=224 || a===198 && (b===18 || b===19)) throw new Error('暂不采集本机或内网地址');
    }
    url.hash = '';
    return url.href;
  }
  function isPage(value) { try { publicUrl(value); return true; } catch { return false; } }
  function provider(value) {
    const url = new URL(publicUrl(value));
    return /(^|\.)pinterest\.com$/.test(url.hostname) ? 'Pinterest' : url.hostname.replace(/^www\./, '');
  }
  function sourceUrl(value) {
    const url = new URL(publicUrl(value));
    if (['www.pinterest.com','pinterest.com'].includes(url.hostname) && /^\/pin\/\d+\/?$/.test(url.pathname)) return `https://www.pinterest.com${url.pathname.replace(/\/?$/, '/')}`;
    return url.href;
  }
  function uuid() {
    if (globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID();
    const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = bytes[6] & 15 | 64; bytes[8] = bytes[8] & 63 | 128;
    const hex = Array.from(bytes, b=>b.toString(16).padStart(2,'0')).join('');
    return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
  }
  globalThis.HubCollectorPolicy = { publicUrl, isPage, provider, sourceUrl, uuid };
})();
