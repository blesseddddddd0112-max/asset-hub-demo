// Repair only authorized sites, without reloading user pages.
export function createConnectionRecovery(api, { APP, isApp, isPinterest, getVersion = async () => null }) {
  const repairing = new Map();
  let receiver;
  let recentlyCreated;
  async function createReceiver(options) {
    const tab = await api.tabs.create(options);
    recentlyCreated = { ...tab, createdAt: Date.now() };
    return tab;
  }
  function repair(tab) {
    if (!tab.id || (!isApp(tab.url) && !isPinterest(tab.url))) return Promise.resolve();
    if (repairing.has(tab.id)) return repairing.get(tab.id);
    const task = (async () => {
      try {
        const pong = await api.tabs.sendMessage(tab.id, { type: 'collectorPing' },{frameId:0});
        const scriptVersion = api.runtime?.getManifest?.().version;
        if (pong?.ready && (!scriptVersion || pong.scriptVersion === scriptVersion)) return;
      } catch { /* Missing or invalidated script. */ }
      await api.scripting.executeScript({ target: { tabId: tab.id }, files: isApp(tab.url)
        ? ['bridge.js'] : ['media-policy.js','web.js','toolbar-style.js', 'toolbar.js', 'pinterest.js'] });
    })().finally(() => repairing.delete(tab.id));
    repairing.set(tab.id, task);
    return task;
  }
  async function repairOpenTabs() {
    const tabs = await api.tabs.query({ url: ['http://*/*','https://*/*'] });
    await Promise.allSettled(tabs.filter(t => isApp(t.url) || isPinterest(t.url)).map(repair));
  }
  function ensureReceiver() {
    if (receiver) return receiver;
    receiver = (async () => {
      const tabs = await api.tabs.query({ url: 'https://blesseddddddd0112-max.github.io/*' });
      const candidates = tabs.filter(t => isApp(t.url));
      const version = await getVersion().catch(() => null);
      // Old pages may have a healthy bridge but no current receiver code.
      // Leave those pages intact and use a dedicated, current receiver instead.
      if (version) {
        for (const candidate of candidates) {
          try {
            await repair(candidate);
            const pong = await api.tabs.sendMessage(candidate.id, { type: 'collectorPing' },{frameId:0});
            if (pong?.receiver?.protocol >= version.receiverProtocol && pong.receiver.buildId === version.buildId && !pong.receiver.updating) return candidate;
          } catch { /* An old/error page cannot be trusted as the receiver. */ }
        }
        const target = candidates.find(t => new URL(t.url).searchParams.get('collectorReceiver') === '1' && new URL(t.url).searchParams.get('collectorBuild') === version.buildId);
        if (target) { await repair(target).catch(() => {}); return target; }
        // tabs.create resolves before its URL necessarily appears in tabs.query.
        // Keep that in-flight tab instead of opening duplicates during bootstrap.
        if (recentlyCreated && Date.now() - recentlyCreated.createdAt < 15000) {
          try { return api.tabs.get ? await api.tabs.get(recentlyCreated.id) : recentlyCreated; }
          catch { recentlyCreated = null; }
        }
        const dedicated = candidates.find(t => new URL(t.url).searchParams.get('collectorReceiver') === '1');
        if (dedicated) {
          try {
            await repair(dedicated);
            const pong = await api.tabs.sendMessage(dedicated.id, { type: 'collectorPing' },{frameId:0});
            // A dedicated page with no edits can finish its job, then update itself.
            if (pong?.receiver?.protocol >= version.receiverProtocol && !pong.receiver.dirty) return dedicated;
            if (new URL(dedicated.url).searchParams.get('collectorBuild') === version.buildId) return dedicated;
          } catch { await api.tabs.reload(dedicated.id); return dedicated; }
        }
        const url = new URL(APP);
        url.searchParams.set('collectorReceiver','1');
        url.searchParams.set('collectorBuild',version.buildId);
        return createReceiver({url:url.href,active:false});
      }
      const tab = candidates[0];
      if (tab) {
        try { await repair(tab); }
        catch { // A receiver opened while the local service was down may be a browser error page.
          await api.tabs.reload(tab.id);
        }
        return tab;
      }
      return createReceiver({ url: APP, active: false });
    })().finally(() => { receiver = null; });
    return receiver;
  }
  return { repair, repairOpenTabs, ensureReceiver };
}
