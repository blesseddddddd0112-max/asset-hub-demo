import { APP, CHUNK, MAX_BYTES, MAX_VIDEO_BYTES, mediaUrl, sourceUrl, sourceProvider, isApp, isCollectablePage } from './protocol.js';
import { createJobStorage } from './job-storage.js';
import { createConnectionRecovery } from './connection.js';
let versionCache=null,versionCheckedAt=0;
async function getReceiverVersion(){return null;}
const recovery = createConnectionRecovery(chrome, { APP, isApp, isPinterest:isCollectablePage, getVersion:getReceiverVersion });
const key = id => `job:${id}`;
let serial = Promise.resolve();
const exclusive = fn => { const next = serial.then(fn, fn); serial = next.catch(() => {}); return next; };
const jobStorage=createJobStorage(chrome.storage.local,CHUNK);
async function jobs(){return jobStorage.list();}
async function save(job){return jobStorage.save(job);}
function summary(job) { const { data, ...rest } = job; return rest; }
async function download(job) {
  let downloading={...job,status:'fetching',payloadReady:false,error:''};
  await jobStorage.clearPayload(job);
  await save(downloading);
  try {
    const response = await fetch(mediaUrl(job.imageUrl), { credentials: 'include', redirect: 'error', signal: AbortSignal.timeout(job.mediaType === 'video' ? 120000 : 20000) });
    const video = job.mediaType === 'video'; const limit = video ? MAX_VIDEO_BYTES : MAX_BYTES;
    if (!response.ok) throw new Error(`获取素材失败（${response.status}）`);
    let mime = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    const binaryMime=['','application/octet-stream','binary/octet-stream'].includes(mime);
    if(mime==='text/html')throw new Error('素材地址返回了网页，可能需要登录或受到防盗链限制');
    if (!binaryMime && !(video ? ['video/mp4', 'video/webm'] : ['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif']).includes(mime)) throw new Error(video ? '仅支持直接下载的 MP4 / WebM，暂不支持流式视频' : '暂不支持此图片格式');
    if (Number(response.headers.get('content-length')) > limit) throw new Error(video ? '视频超过 100 MB' : '图片超过 20 MB');
    const reader = response.body.getReader(); const pieces = []; let size = 0;
    while (true) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > limit) { await reader.cancel(); throw new Error(video ? '视频超过 100 MB' : '图片超过 20 MB'); } pieces.push(value); }
    if (!size) throw new Error('素材文件为空');
    const bytes = new Uint8Array(size); let offset = 0;
    for (const p of pieces) { bytes.set(p, offset); offset += p.length; }
    if(binaryMime){const ascii=(start,end)=>String.fromCharCode(...bytes.subarray(start,end));mime=video?(ascii(4,8)==='ftyp'?'video/mp4':bytes[0]===0x1a&&bytes[1]===0x45&&bytes[2]===0xdf&&bytes[3]===0xa3?'video/webm':''):bytes[0]===0xff&&bytes[1]===0xd8?'image/jpeg':bytes[0]===0x89&&ascii(1,4)==='PNG'?'image/png':ascii(0,3)==='GIF'?'image/gif':ascii(0,4)==='RIFF'&&ascii(8,12)==='WEBP'?'image/webp':ascii(4,8)==='ftyp'&&/avif|avis/.test(ascii(8,20))?'image/avif':'';if(!mime)throw new Error('无法识别素材文件格式');}
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), b => b.toString(16).padStart(2, '0')).join('');
    downloading={...downloading,mime,size,hash,chunkCount:Math.ceil(Math.ceil(size/3)*4/CHUNK)};
    await save(downloading);
    await jobStorage.writePayload(job.id,bytes);
    await save({...downloading,status:'waiting',payloadReady:true});
  } catch(error){await save({...downloading,status:'failed',error:error.message});}
}
async function handle(message, sender) {
  const extension = sender.url?.startsWith(chrome.runtime.getURL(''));
  const app = isApp(sender.url);
  const pinterest = isCollectablePage(sender.url);
  if (!extension && !app && !pinterest) throw new Error('来源未授权');
  if (['enqueue', 'generate'].includes(message.type) && (extension || pinterest)) return exclusive(async () => {
    const source = sourceUrl(message.item?.pinUrl); const image = mediaUrl(message.item?.imageUrl);
    const transformation = message.type === 'generate';
    const mediaType = message.item?.mediaType === 'video' ? 'video' : 'image';

    if (transformation && !['prompt','script','skill'].includes(message.outputType)) throw new Error('无效的生成类型');
    const clientRequestId = typeof message.clientRequestId === 'string' && /^[a-f0-9-]{36}$/.test(message.clientRequestId) ? message.clientRequestId : undefined;
    const previous = (await jobs()).find(j => transformation ? clientRequestId && j.clientRequestId === clientRequestId && j.pinUrl === source : !j.kind && j.pinUrl === source && j.imageUrl === image && j.status !== 'failed');
    if (previous) { void recovery.ensureReceiver().catch(() => {}); return summary(previous); }
    const job = { id: crypto.randomUUID(), mediaType, provider:sourceProvider(source),key:message.item?.key?`${mediaType}:${image}`:source,pinUrl: source, imageUrl: image, title: String(message.item.title || '网页素材').slice(0, 200), capturedAt: new Date().toISOString(), status: 'queued', ...(transformation ? {kind:'transform',clientRequestId,outputType:message.outputType,instruction:String(message.instruction||'').slice(0,2000)} : {}) };
    await save(job); void recovery.ensureReceiver().catch(() => {}); return summary(job);
  });
  if (message.type === 'saveDocument' && (extension || pinterest)) return exclusive(async () => {
    const parent = (await chrome.storage.local.get(key(message.parentId)))[key(message.parentId)];
    if(parent?.status !== 'generated' || parent.kind !== 'transform') throw new Error('请先完成生成并检查结果');
    const text=String(message.text||'').trim(); if(!text || text.length>64000) throw new Error('内容不能为空或超过长度限制');
    const existing=(await jobs()).find(j=>j.kind==='document' && j.parentId===parent.id && j.text===text && j.status!=='failed');if(existing)return summary(existing);
    return summary(await save({id:crypto.randomUUID(),parentId:parent.id,kind:'document',outputType:parent.outputType,text,title:String(message.title||parent.result.title).slice(0,120),provider:parent.provider,pinUrl:parent.pinUrl,imageUrl:parent.imageUrl,capturedAt:new Date().toISOString(),status:'waiting'}));
  });
  if (message.type === 'list' && (extension || pinterest)) { const { connectedAt,receiverState } = await chrome.storage.local.get(['connectedAt','receiverState']); return { jobs: (await jobs()).map(summary), connected: Date.now() - (connectedAt || 0) < 15000,processingJobId:receiverState&&Date.now()-receiverState.at<15000?receiverState.jobId:null }; }
  if (message.type === 'retry' && (extension || pinterest)) return exclusive(async () => { const job = (await chrome.storage.local.get(key(message.id)))[key(message.id)]; if (job?.status === 'failed') await save({ ...job, status: job.data || job.payloadReady ? 'waiting' : 'queued', error: '' }); void recovery.ensureReceiver().catch(()=>{}); return true; });
  if (message.type === 'open' && (extension || pinterest)) { await chrome.tabs.create({ url: message.settings ? new URL('/collector/model-setup',APP).href : APP }); return true; }
  if(app && message.type==='receiverHealth'){const hasPending=(await jobs()).some(j=>['queued','fetching','waiting'].includes(j.status));if(hasPending)void recovery.ensureReceiver().catch(()=>{});return {hasPending,version:await getReceiverVersion().catch(()=>null)};}
  if(app && message.type==='heartbeat'){const {receiverState}=await chrome.storage.local.get('receiverState');const values={connectedAt:Date.now()};if(message.protocol>=2&&(message.jobId||!receiverState||receiverState.tabId===sender.tab?.id||Date.now()-receiverState.at>15000))values.receiverState={protocol:message.protocol,buildId:message.buildId,jobId:message.jobId||null,at:Date.now(),tabId:sender.tab?.id};await chrome.storage.local.set(values);return {connected:true};}
  if (app && message.type === 'poll') {
    await chrome.storage.local.set({ connectedAt: Date.now() });
    return (await jobs()).filter(j => j.status === 'waiting').sort((a,b)=>a.capturedAt.localeCompare(b.capturedAt)).map(summary).slice(0, 1);
  }
  if (app && message.type === 'chunk') {
    const job = (await chrome.storage.local.get(key(message.id)))[key(message.id)];
    if (job?.status !== 'waiting' || !Number.isInteger(message.index) || message.index < 0) throw new Error('任务不可读取');
    return jobStorage.readChunk(job,message.index);
  }
  if (app && message.type === 'ack') return exclusive(async () => {
    const job = (await chrome.storage.local.get(key(message.id)))[key(message.id)];
    if (job?.status !== 'waiting') return false;
    if (message.error) await save({ ...job, status: 'failed', error: String(message.error).slice(0, 200) });
    else { const { data, ...rest } = job; if(job.kind==='transform') { if(typeof message.result?.text!=='string' || message.result.text.length>64000) throw new Error('生成结果无效'); await save({...rest,status:'generated',result:message.result}); } else await save({ ...rest, status: message.existing ? 'existing' : 'saved', assetId: message.assetId }); await jobStorage.clearPayload(job).catch(()=>{}); }
    return true;
  });
  throw new Error('不支持此操作');
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  handle(message, sender).then(result => respond({ ok: true, result }), error => respond({ ok: false, error: error.message })); return true;
});
// The existing local receiver can wake a newly reloaded worker even when its old bridge is invalid.
chrome.runtime.onMessageExternal.addListener((message,sender,respond)=>{
  if(!isApp(sender.url)||!['heartbeat','poll','chunk','ack'].includes(message?.type)){respond({ok:false,error:'来源或操作未授权'});return false;}
  handle(message,sender).then(result=>respond({ok:true,result}),error=>respond({ok:false,error:error.message}));return true;
});
// Queue work is resumable: alarms and panel heartbeats restart interrupted downloads.
let pumping = false;
async function pump() {
  if (pumping) return; pumping = true;
  try { while (true) { const job = (await jobs()).find(j => ['queued', 'fetching'].includes(j.status)); if (!job) break; await download(job); } }
  finally { pumping = false; }
}
chrome.storage.onChanged.addListener(changes => { if (Object.keys(changes).some(k => k.startsWith('job:'))) void pump(); });
chrome.alarms.onAlarm.addListener(() => { void pump(); void recoverConnections(); });
chrome.alarms.create('resume', { periodInMinutes: 1 });
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
chrome.action.onClicked.addListener(async tab => {
  if (!tab.id) return;
  try { await chrome.tabs.sendMessage(tab.id, { type: 'toggleToolbar' },{frameId:0}); }
  catch { if (isCollectablePage(tab.url)) { try{await recovery.repair(tab);await chrome.tabs.sendMessage(tab.id,{type:'showToolbar'},{frameId:0});}catch{await chrome.sidePanel.open({tabId:tab.id});} } else await chrome.sidePanel.open({tabId:tab.id}); }
});
chrome.runtime.onInstalled.addListener(async()=>{await chrome.contextMenus.remove('collect').catch(()=>{});chrome.contextMenus.create({id:'collect',title:'采集素材',contexts:['image','video'],documentUrlPatterns:['http://*/*','https://*/*']});});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'collect' || !tab?.id) return;
  try { const item = await chrome.tabs.sendMessage(tab.id, { type: 'contextCandidate', src: info.srcUrl },{frameId:info.frameId||0}); if (item) await handle({ type: 'enqueue', item }, { url: tab.url }); else await chrome.sidePanel.open({ tabId: tab.id }); } catch { await chrome.sidePanel.open({ tabId: tab.id }); }
});
void pump();
void recoverConnections();
chrome.runtime.onStartup.addListener(() => void recoverConnections());
chrome.runtime.onInstalled.addListener(() => void recoverConnections());
async function recoverConnections() {
  await recovery.repairOpenTabs();
  if ((await jobs()).some(j => ['queued','fetching','waiting'].includes(j.status))) await recovery.ensureReceiver().catch(() => {});
}
