// Keep binary payloads out of status polling; large videos must not be copied
// from extension storage again for every list/heartbeat request.
export function createJobStorage(storage, chunkSize) {
  let indexPromise;
  async function ids() {
    if (!indexPromise) indexPromise = (async () => {
      const existing = await storage.get('collectorJobIds');
      if (Array.isArray(existing.collectorJobIds)) return existing.collectorJobIds;
      const all = await storage.get(null);
      const result = Object.keys(all).filter(k => k.startsWith('job:')).map(k => k.slice(4));
      await storage.set({ collectorJobIds: result });
      return result;
    })();
    return indexPromise;
  }
  async function save(job) {
    const index = await ids();
    const fresh = !index.includes(job.id);
    if (fresh) index.push(job.id);
    await storage.set({ [`job:${job.id}`]: job, ...(fresh ? { collectorJobIds: [...index] } : {}) });
    return job;
  }
  async function list() {
    const index = await ids();
    if (!index.length) return [];
    const records = await storage.get(index.map(id => `job:${id}`));
    return index.map(id => records[`job:${id}`]).filter(Boolean);
  }
  async function writePayload(id, bytes) {
    const bytesPerChunk = chunkSize / 4 * 3;
    let count = 0;
    for (let offset = 0; offset < bytes.length; offset += bytesPerChunk) {
      const part = bytes.subarray(offset, offset + bytesPerChunk);
      let binary = '';
      for (let i = 0; i < part.length; i += 8192) binary += String.fromCharCode(...part.subarray(i, i + 8192));
      await storage.set({ [`payload:${id}:${count++}`]: btoa(binary) });
    }
    return count;
  }
  async function readChunk(job, index) {
    if (job.data) return { data: job.data.slice(index * chunkSize, (index + 1) * chunkSize), count: Math.ceil(job.data.length / chunkSize) };
    if (!job.payloadReady || index >= job.chunkCount) throw new Error('素材文件未准备完成');
    const key = `payload:${job.id}:${index}`;
    const value = (await storage.get(key))[key];
    if (typeof value !== 'string') throw new Error('素材文件分块缺失，请重新采集');
    return { data: value, count: job.chunkCount };
  }
  async function clearPayload(job) {
    if (job.chunkCount) await storage.remove(Array.from({ length: job.chunkCount }, (_, i) => `payload:${job.id}:${i}`));
  }
  return { save, list, writePayload, readChunk, clearPayload };
}
